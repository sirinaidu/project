package org.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.claims.dao.AdjusterDaoImpl;
import org.cts.claims.dao.ClaimDaoImpl;
import org.cts.claims.model.Claim;

@WebServlet("/assignAdjuster")
public class AssignAdjusterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       AdjusterDaoImpl dao=new AdjusterDaoImpl();
       ClaimDaoImpl claimdao=new ClaimDaoImpl();
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");
	        PrintWriter pw = response.getWriter();
	        Connection conn = null;
	        String url = "jdbc:mysql://localhost:3306/";
	        String dbName = "claimsdb";
	        String driver = "com.mysql.jdbc.Driver";
	        String userName = "root";
	        String password = "root";
	        Statement st=null;	
	        String m="";
		try {
            Class.forName(driver).newInstance();
            conn = DriverManager.getConnection(url + dbName, userName, password);
            System.out.println("connected!.....");
            String cid = request.getParameter("claim_Id");
            String aid=request.getParameter("Adjuster_id");
            String query ="update claims set adjuster_id='"+aid+"' "+"where id='"+cid+"' ";
            System.out.println("query " + query);
            st = conn.createStatement();
            st.executeUpdate(query);
            conn.close();
            pw.write(m);
    		response.sendRedirect("csr.jsp");
		}
    		catch (Exception e) {
	            e.printStackTrace();
	        }
	
	}

}
