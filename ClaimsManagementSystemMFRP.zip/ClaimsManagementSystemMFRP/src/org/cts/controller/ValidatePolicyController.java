package org.cts.controller;



import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.claims.dao.PolicyDaoImpl;
import org.cts.claims.model.Policy;




@WebServlet("/validatePolicy")

public class ValidatePolicyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PolicyDaoImpl dao=new PolicyDaoImpl();
	String msg="";
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int pid=Integer.parseInt(request.getParameter("id"));
		//String pid=request.getParameter("id")
		System.out.println(pid);
		Policy p=dao.getPolicy(pid);
		if(p==null)
		{
			msg=msg+"Policy not existed";
		}
		pw.write(msg);
		msg="";
		pw.close();

	}



}