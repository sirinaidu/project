package org.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.claims.dao.AuthenticationDaoImpl;
import org.cts.claims.dao.Authentication_Dao;
import org.cts.claims.dao.ClaimDaoImpl;
import org.cts.claims.model.Authentication;
import org.cts.claims.model.Claim;

/**
 * Servlet implementation class AddUserServlet
 */
 @WebServlet("/concludeClaims")
 public class ConcludeClaimController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ClaimDaoImpl dao = new ClaimDaoImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int claimId=Integer.parseInt(request.getParameter("claimId"));
		int cId=Integer.parseInt(request.getParameter("CId"));
		double subClaimAmt=Double.parseDouble(request.getParameter("subClaimAmt"));
		double salRecAmt=Double.parseDouble(request.getParameter("salRecAmt"));
		 Claim claim = 	dao.getClaim(claimId);
		 claim.setSub_claim_amt(subClaimAmt);
		 claim.setStatus("closed");
		 claim.setSalvage_rec_amt(salRecAmt);
			String msg=dao.insert(claimId,cId,subClaimAmt,salRecAmt,claim);
			pw.println("<script>alert(msg);</script>");
		
		
		response.sendRedirect("adjuster.jsp");
	}
}


