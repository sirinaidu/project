package org.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.claims.dao.AutoClaimsInfoDao;
import org.cts.claims.dao.AutoClaimsInfoDaoImpl;
import org.cts.claims.dao.ClaimDaoImpl;
import org.cts.claims.model.AutoClaimsInfo;
import org.cts.claims.model.Claim;


@WebServlet("/autoClaims")
public class AutoClaimsController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	AutoClaimsInfoDao dao=new AutoClaimsInfoDaoImpl();
	ClaimDaoImpl dao2 = new ClaimDaoImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		//int claimId=Integer.parseInt(request.getParameter("claimid"));
		int customerId=Integer.parseInt(request.getParameter("customerid"));
		String status="Reported";
		String date = request.getParameter("claim_set_date");
		double claimsetamt=Double.parseDouble(request.getParameter("claimsetamt"));
		int autoclaimsId=Integer.parseInt(request.getParameter("autoclaimsid"));
		int policy_Id=Integer.parseInt(request.getParameter("policyid"));
		String dLicense=request.getParameter("dlicense");
		String vLicense=request.getParameter("vlicense");
		String model=request.getParameter("amodel");
		int year=Integer.parseInt(request.getParameter("year"));
		String accident_date=request.getParameter("accident_date");
		String accident_place=request.getParameter("accident_place");
		String details=request.getParameter("details");
		String policev=request.getParameter("policev");
		AutoClaimsInfo autoClaimsInfo = new AutoClaimsInfo(autoclaimsId, dLicense, vLicense,
				model, year, accident_date, accident_place, details, policev);
		Claim claim = new Claim(customerId,status,date,claimsetamt, 0,0, policy_Id,"Auto", autoclaimsId);
		String msg=dao.insertAutoClaimsInfo(autoClaimsInfo);
		String msg2=dao2.insertAutoClaim(claim);
		//pw.println("<script>alert(msg);</script>");
		response.sendRedirect("csr.jsp");
		
		/*if(msg.equalsIgnoreCase("Success") && msg2.equalsIgnoreCase("success"))
		{
		pw.println("<script type=\"text/javascript\">");
		pw.println("alert('successfuuly Inserted');");
		pw.println("</script>");
		RequestDispatcher rd=request.getRequestDispatcher("csr.jsp");
		rd.include(request,response);
		}
		else
		{
			pw.println("<script type=\"text/javascript\">");
			pw.println("alert('fails');");
			pw.println("</script>");
			RequestDispatcher rd=request.getRequestDispatcher("csr.jsp");
			rd.include(request, response);
		}*/
	}

}
