package org.cts.claims.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.cts.claims.model.Customer;
import org.cts.claims.model.Policy;
import org.cts.claims.util.DBConstants;
import org.cts.claims.util.DBUtil;

public class CustomerDaoImpl implements CustomerDao {
	Connection connection = null;
	
	public Customer getCustomer (int cid){
		Customer customer=null;
		try {
			    connection = DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME , DBConstants.PWD);
				PreparedStatement preparedStatement = connection.prepareStatement("select * from customer where id = ?");
				preparedStatement.setInt(1, cid);
				ResultSet resultSet  = preparedStatement.executeQuery();
				if(resultSet.next())
				customer = new Customer(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5),resultSet.getString(2));
				connection.close();  
				
		  }
		  catch (Exception e) {
			  e.printStackTrace();
		  }
		// TODO Auto-generated method stub
		return customer;
	}
}
