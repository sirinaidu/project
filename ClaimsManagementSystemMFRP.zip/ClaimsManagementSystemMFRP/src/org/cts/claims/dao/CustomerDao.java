package org.cts.claims.dao;

import org.cts.claims.model.Customer;

public interface CustomerDao {
	Customer getCustomer (int cid);
}
